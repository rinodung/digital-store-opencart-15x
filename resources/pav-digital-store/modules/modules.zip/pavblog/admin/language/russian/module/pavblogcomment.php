<?php
// Заголовок
$_['heading_title'] = ' <span style="color:#E1653B"> Пав Блог Последний комментарий Модуль </ span> ' ;

// Подпись под аватаром
$_['text_module'] = ' Модули ' ;
$_['text_success'] = ' Успех : Вы изменили модуль слайд-шоу ' ;
$_['text_content_top'] = 'Content Top' ;
$_['text_content_bottom'] = 'Content дно ' ;
$_['text_column_left'] = ' колонки левые ';
$_['text_column_right'] = ' столбец справа ';
$_['text_mainmenu'] = ' Главное меню ' ;
$_['text_slideshow'] = ' Слайд-шоу ' ;
$_['text_promotion'] = ' поощрения ' ;
$_['text_bottom1'] = ' снизу 1 ' ;
$_['text_bottom2'] = ' снизу 2 ' ;
$_['text_bottom3'] = ' Нижняя 3' ;
$_['text_footer_top'] = ' Footer Top' ;
$_['text_footer_center'] = ' Footer Центра';
$_['text_footer_bottom'] = ' Footer дно ' ;
$_['all_page'] = ' Все страницы ' ;
// Вступление
$_['entry_banner'] = ' Баннер :';
$_['entry_dimension'] = ' Размеры ( Ш х В) и изменение размера Тип :';
$_['entry_layout'] = ' Макет :';
$_['entry_position'] = ' Позиция :';
$_['entry_status'] = ' Статус :';
$_['entry_sort_order'] = ' сортировку :';
$_['entry_carousel'] = ' ограничения на товары :';
$_['Entry_tabs'] = ' Продукт Tab типов';
$_['Entry_description'] = ' Модуль Описание' ;


$_['text_latest'] = ' Последние ' ;
$_['text_mostviewed'] = ' Самые популярные ';
$_['text_featured'] = ' Лучшее ' ;
$_['text_bestseller'] = ' Бестселлер ' ;
$_['text_special'] = ' Специальные ' ;
$_['button_blog_management'] = ' Блог менеджмент ';
// Ошибка
$_['error_permission'] = ' Внимание: У вас нет разрешения на изменение модуля слайд-шоу ' ;
$_['error_dimension'] = ' Ширина и Высота размеры требуются! ' ;
$_['error_carousel'] = ' Максимальная ширина и товары - Макс Столбцы - ограничения на товары в Карусели требуются! ' ;

?>
