<?php
$_['entry_newsletter'] = "Newsletter";
$_['button_ok'] = "Ok";
$_['default_input_text'] = "Your email address";