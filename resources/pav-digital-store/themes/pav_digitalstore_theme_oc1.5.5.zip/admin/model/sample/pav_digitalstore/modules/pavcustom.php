a:7:{i:1;a:8:{s:12:"module_title";a:3:{i:1;s:17:"Banner MassBottom";i:3;s:17:"Banner MassBottom";i:4;s:17:"Banner MassBottom";}s:11:"description";a:3:{i:1;s:1344:"&lt;div class=&quot;media-list row &quot;&gt;
&lt;div class=&quot;col-lg-6 col-md-6 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media gray&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner3.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-primary-theme&quot;&gt;Ipad in education&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo sit amet nibh libero itudin commodoturpis&lt;/p&gt;

&lt;p class=&quot;readmore&quot;&gt;&lt;a href=&quot;#&quot;&gt;Readmore&lt;/a&gt;&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-6 col-md-6 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media gray&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner4.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading&quot;&gt;MacBook Pro&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo sit amet nibh libero itudin commodoturpis&lt;/p&gt;

&lt;p class=&quot;readmore&quot;&gt;&lt;a href=&quot;#&quot;&gt;Readmore&lt;/a&gt;&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:3;s:1344:"&lt;div class=&quot;media-list row &quot;&gt;
&lt;div class=&quot;col-lg-6 col-md-6 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media gray&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner3.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-primary-theme&quot;&gt;Ipad in education&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo sit amet nibh libero itudin commodoturpis&lt;/p&gt;

&lt;p class=&quot;readmore&quot;&gt;&lt;a href=&quot;#&quot;&gt;Readmore&lt;/a&gt;&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-6 col-md-6 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media gray&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner4.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading&quot;&gt;MacBook Pro&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo sit amet nibh libero itudin commodoturpis&lt;/p&gt;

&lt;p class=&quot;readmore&quot;&gt;&lt;a href=&quot;#&quot;&gt;Readmore&lt;/a&gt;&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:4;s:1344:"&lt;div class=&quot;media-list row &quot;&gt;
&lt;div class=&quot;col-lg-6 col-md-6 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media gray&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner3.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading text-primary-theme&quot;&gt;Ipad in education&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo sit amet nibh libero itudin commodoturpis&lt;/p&gt;

&lt;p class=&quot;readmore&quot;&gt;&lt;a href=&quot;#&quot;&gt;Readmore&lt;/a&gt;&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-6 col-md-6 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media gray&quot;&gt;&lt;a class=&quot;pull-right&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/banner4.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h3 class=&quot;media-heading&quot;&gt;MacBook Pro&lt;/h3&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollicitudin commodo sit amet nibh libero itudin commodoturpis&lt;/p&gt;

&lt;p class=&quot;readmore&quot;&gt;&lt;a href=&quot;#&quot;&gt;Readmore&lt;/a&gt;&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:11:"mass_bottom";s:6:"status";s:1:"1";s:12:"module_class";s:14:" no-boxshadown";s:10:"sort_order";s:1:"2";}i:2;a:8:{s:12:"module_title";a:3:{i:1;s:6:"Social";i:3;s:0:"";i:4;s:0:"";}s:11:"description";a:3:{i:1;s:660:"&lt;p&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-pinterest&quot;&gt;&amp;nbsp;&lt;/i&gt;Pinterest&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-facebook&quot;&gt;&amp;nbsp;&lt;/i&gt;Facebook&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-google-plus&quot;&gt;&amp;nbsp;&lt;/i&gt;Google+&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-twitter&quot;&gt;&amp;nbsp;&lt;/i&gt;Twitter&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-youtube&quot;&gt;&amp;nbsp;&lt;/i&gt;Youtube&lt;/a&gt;&lt;/p&gt;
";i:3;s:660:"&lt;p&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-pinterest&quot;&gt;&amp;nbsp;&lt;/i&gt;Pinterest&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-facebook&quot;&gt;&amp;nbsp;&lt;/i&gt;Facebook&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-google-plus&quot;&gt;&amp;nbsp;&lt;/i&gt;Google+&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-twitter&quot;&gt;&amp;nbsp;&lt;/i&gt;Twitter&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-youtube&quot;&gt;&amp;nbsp;&lt;/i&gt;Youtube&lt;/a&gt;&lt;/p&gt;
";i:4;s:660:"&lt;p&gt;&lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-pinterest&quot;&gt;&amp;nbsp;&lt;/i&gt;Pinterest&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-facebook&quot;&gt;&amp;nbsp;&lt;/i&gt;Facebook&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-google-plus&quot;&gt;&amp;nbsp;&lt;/i&gt;Google+&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-twitter&quot;&gt;&amp;nbsp;&lt;/i&gt;Twitter&lt;/a&gt; &lt;a href=&quot;#&quot; title=&quot;&quot;&gt;&lt;i class=&quot;fa fa-youtube&quot;&gt;&amp;nbsp;&lt;/i&gt;Youtube&lt;/a&gt;&lt;/p&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:10:"footer_top";s:6:"status";s:1:"1";s:12:"module_class";s:6:"social";s:10:"sort_order";s:1:"2";}i:3;a:8:{s:12:"module_title";a:3:{i:1;s:10:"List Order";i:3;s:10:"List Order";i:4;s:10:"List Order";}s:11:"description";a:3:{i:1;s:1987:"&lt;div class=&quot;media-list row&quot;&gt;
&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media red&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-free.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Free Shipping&lt;/h4&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollici.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media green&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-money.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Money back&lt;/h4&gt;

&lt;p&gt;Cras purus odio, in tempus viverra turpis.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media blue&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-discounts.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Discounts&lt;/h4&gt;

&lt;p&gt;Cras sit amet nibh libero itudin commo.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media dark&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-support.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Support&lt;/h4&gt;

&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:3;s:1987:"&lt;div class=&quot;media-list row&quot;&gt;
&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media red&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-free.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Free Shipping&lt;/h4&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollici.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media green&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-money.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Money back&lt;/h4&gt;

&lt;p&gt;Cras purus odio, in tempus viverra turpis.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media blue&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-discounts.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Discounts&lt;/h4&gt;

&lt;p&gt;Cras sit amet nibh libero itudin commo.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media dark&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-support.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Support&lt;/h4&gt;

&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";i:4;s:1987:"&lt;div class=&quot;media-list row&quot;&gt;
&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media red&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-free.png&quot; /&gt; &lt;/a&gt;
&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Free Shipping&lt;/h4&gt;

&lt;p&gt;Nulla vel metus scelerisque ante sollici.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media green&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-money.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Money back&lt;/h4&gt;

&lt;p&gt;Cras purus odio, in tempus viverra turpis.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media blue&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-discounts.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Discounts&lt;/h4&gt;

&lt;p&gt;Cras sit amet nibh libero itudin commo.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;

&lt;div class=&quot;col-lg-3 col-md-3 hidden-sm hidden-xs&quot;&gt;
&lt;div class=&quot;media dark&quot;&gt;&lt;a class=&quot;pull-left&quot; href=&quot;#&quot;&gt;&lt;img class=&quot;media-object&quot; src=&quot;image/data/icon-support.png&quot; /&gt; &lt;/a&gt;

&lt;div class=&quot;media-body&quot;&gt;
&lt;h4 class=&quot;media-heading&quot;&gt;Support&lt;/h4&gt;

&lt;p&gt;Cras sit amet nibh libero, in viverra turpis.&lt;/p&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
&lt;/div&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:1:"1";s:8:"position";s:11:"mass_bottom";s:6:"status";s:1:"1";s:12:"module_class";s:13:"no-boxshadown";s:10:"sort_order";s:1:"1";}i:4;a:8:{s:12:"module_title";a:3:{i:1;s:18:"Banner mass bottom";i:3;s:18:"Banner mass bottom";i:4;s:18:"Banner mass bottom";}s:11:"description";a:3:{i:1;s:167:"&lt;p class=&quot;hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner-mass-bottom.jpg&quot; style=&quot;border-radius: 5px;&quot; /&gt;&lt;/p&gt;
";i:3;s:167:"&lt;p class=&quot;hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner-mass-bottom.jpg&quot; style=&quot;border-radius: 5px;&quot; /&gt;&lt;/p&gt;
";i:4;s:167:"&lt;p class=&quot;hidden-xs&quot;&gt;&lt;img alt=&quot;&quot; src=&quot;image/data/banner-mass-bottom.jpg&quot; style=&quot;border-radius: 5px;&quot; /&gt;&lt;/p&gt;
";}s:10:"show_title";s:1:"0";s:9:"layout_id";s:5:"99999";s:8:"position";s:11:"mass_bottom";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"4";}i:5;a:8:{s:12:"module_title";a:3:{i:1;s:10:"Contact Us";i:3;s:10:"Contact Us";i:4;s:10:"Contact Us";}s:11:"description";a:3:{i:1;s:505:"&lt;p&gt;If your question is not answered there, please use one of the contact methods below.&lt;/p&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-map-marker&quot;&gt;&amp;nbsp;&lt;/span&gt;Proin gravida, velit auctor aliquet&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-mobile-phone&quot;&gt;&amp;nbsp;&lt;/span&gt;Phone: +01 888 (000) 1234&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-envelope&quot;&gt;&amp;nbsp;&lt;/span&gt;Email: pavdigitaltore@gmail.com&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:505:"&lt;p&gt;If your question is not answered there, please use one of the contact methods below.&lt;/p&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-map-marker&quot;&gt;&amp;nbsp;&lt;/span&gt;Proin gravida, velit auctor aliquet&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-mobile-phone&quot;&gt;&amp;nbsp;&lt;/span&gt;Phone: +01 888 (000) 1234&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-envelope&quot;&gt;&amp;nbsp;&lt;/span&gt;Email: pavdigitaltore@gmail.com&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:505:"&lt;p&gt;If your question is not answered there, please use one of the contact methods below.&lt;/p&gt;

&lt;ul&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-map-marker&quot;&gt;&amp;nbsp;&lt;/span&gt;Proin gravida, velit auctor aliquet&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-mobile-phone&quot;&gt;&amp;nbsp;&lt;/span&gt;Phone: +01 888 (000) 1234&lt;/li&gt;
	&lt;li&gt;&lt;span class=&quot;fa fa-envelope&quot;&gt;&amp;nbsp;&lt;/span&gt;Email: pavdigitaltore@gmail.com&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:10:"contact-us";s:10:"sort_order";i:3;}i:6;a:8:{s:12:"module_title";a:3:{i:1;s:16:"Customer Service";i:3;s:16:"Customer Service";i:4;s:16:"Customer Service";}s:11:"description";a:3:{i:1;s:571:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Returns&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Site Map&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/manufacturer&quot;&gt;Brands&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:571:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Returns&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Site Map&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/manufacturer&quot;&gt;Brands&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:571:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/contact&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/return/insert&quot;&gt;Returns&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=information/sitemap&quot;&gt;Site Map&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/manufacturer&quot;&gt;Brands&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/voucher&quot;&gt;Gift Vouchers&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"1";}i:7;a:8:{s:12:"module_title";a:3:{i:1;s:10:"My Account";i:3;s:10:"My Account";i:4;s:10:"My Account";}s:11:"description";a:3:{i:1;s:560:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;My Account&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;Order History&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;Wish List&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;Newsletter&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Specials&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:3;s:560:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;My Account&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;Order History&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;Wish List&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;Newsletter&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Specials&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";i:4;s:560:"&lt;ul class=&quot;list&quot;&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/account&quot;&gt;My Account&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/order&quot;&gt;Order History&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/wishlist&quot;&gt;Wish List&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=account/newsletter&quot;&gt;Newsletter&lt;/a&gt;&lt;/li&gt;
	&lt;li&gt;&lt;a href=&quot;index.php?route=product/special&quot;&gt;Specials&lt;/a&gt;&lt;/li&gt;
&lt;/ul&gt;
";}s:10:"show_title";s:1:"1";s:9:"layout_id";s:5:"99999";s:8:"position";s:13:"footer_center";s:6:"status";s:1:"1";s:12:"module_class";s:0:"";s:10:"sort_order";s:1:"2";}}